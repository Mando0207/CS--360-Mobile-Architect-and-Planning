package com.zybooks.weighttracker;


import androidx.room3.Dao;
import androidx.room3.Insert;
import androidx.room3.Query;

@Dao
public interface  UserDao {

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User findUser(String username);

    @Query("SELECT * FROM users WHERE username = :username AND password = :password LIMIT 1")
    User login(String username, String password);

    @Insert
    void insertUser(User user);
}
