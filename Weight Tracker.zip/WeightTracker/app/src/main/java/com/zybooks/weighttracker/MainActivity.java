package com.zybooks.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText theUsername, thePassword;
    Button btnLogin, btnCreateNew;
    AppDatabase db;

    private static final int SMS_PERMISSION_CODE = 1001;
    // Setting the first screen with the UI and the database
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        theUsername = findViewById(R.id.editUsername);
        thePassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.buttonLogin);
        btnCreateNew = findViewById(R.id.buttonCreateAccount);

        db = AppDatabase.getInstance(this);

        btnLogin.setOnClickListener(v -> loginUser());
        btnCreateNew.setOnClickListener(v -> createUser());

        requestSmsPermission();
    }

    // Method to help the user log in and checking the DB for existing account
    private void loginUser() {
        String userName = theUsername.getText().toString().trim();
        String passWord = thePassword.getText().toString().trim();

        if (userName.isEmpty() || passWord.isEmpty()) {
            Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            return;
        }

        User theUser = db.userDao().login(userName, passWord);

        if (theUser != null) {
            Toast.makeText(this, "Login was successful", Toast.LENGTH_SHORT).show();

            sendSmsAlert("5551234567", "You logged in to Weight Tracker!");
        } else {
            Toast.makeText(this, "Invalid username and/or password", Toast.LENGTH_SHORT).show();
        }
    }

    // If user does not exist in DB create user requiring both username & password
    private void createUser() {
        String userName = theUsername.getText().toString().trim();
        String passWord = thePassword.getText().toString().trim();

        if (userName.isEmpty() || passWord.isEmpty()) {
            Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            return;
        }

        User userExist = db.userDao().findUser(userName);

        if (userExist != null) {
            Toast.makeText(this, "User already exists, please log in", Toast.LENGTH_SHORT).show();
        } else {
            db.userDao().insertUser(new User(userName, passWord));
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
        }

    }

    // Requesting SMS permission
    private void requestSmsPermission() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String []{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied - app will continue without SMS alerts", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void sendSmsAlert (String phoneNumber, String message) {
        if (checkSelfPermission(Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED) {

            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phoneNumber, null, message, null, null);

        } else {
            Toast.makeText(this, "SMS permission not granted - cannot send alerts", Toast.LENGTH_SHORT).show();
        }
    }
}