package com.zybooks.weighttracker;

import android.content.Context;
import androidx.room3.Database;
import androidx.room3.Room;
import androidx.room3.RoomDatabase;

@Database(entities = {User.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase  {

    private static AppDatabase instance;

    public abstract UserDao userDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "weighttacker.db")
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;
        }
    }

